#!/bin/bash
display_uptime() {
  while true; do
    echo "$(uptime)"
    sleep 5
  done
}

display_uptime
