get_greeting() {
    hour=$(date +"%H")
    if [ $hour -ge 5 ] && [ $hour -lt 12 ]; then
        echo "Good morning"
    elif [ $hour -ge 12 ] && [ $hour -lt 18 ]; then
        echo "Good afternoon"
    else
        echo "Good evening"
    fi
}

# Function to display the greeting and current time
display_greeting() {
    name="Mohit"
    while true; do
        current_time=$(date +"%A, %d %B %Y %I:%M %p")
        greeting=$(get_greeting)
        echo "$greeting, $name! It's $current_time."
        sleep 60  # Wait for 60 seconds before updating again
    done
}

# Run the display_greeting function
display_greeting
