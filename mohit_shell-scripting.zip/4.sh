countdown() {
    duration=$1
    while [ $duration -gt 0 ]; do
        echo -ne "Time remaining: $duration\033[0K\r"
        sleep 1
        ((duration--))
    done
    echo "Time's up!"
}

# Prompt the user for the duration
read -p "Enter the duration: " duration

# Check if the entered duration is a valid positive integer
if ! [[ "$duration" =~ ^[0-9]+$ ]]; then
    echo "Please enter a valid positive number."
    exit 1
fi

# Start the countdown
countdown $duration
