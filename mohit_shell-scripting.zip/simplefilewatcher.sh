#!/bin/bash

# Function to get the file's last modification time
get_modification_time() {
    stat -c %Y "$1"
}

# Prompt the user for the file to monitor
read -p "Enter the file path to monitor: " file_path

# Check if the file exists
if [ ! -f "$file_path" ]; then
    echo "File does not exist."
    exit 1
fi

# Get the initial modification time
initial_mod_time=$(get_modification_time "$file_path")

# Monitor the file for changes
while true; do
    current_mod_time=$(get_modification_time "$file_path")
    if [ "$current_mod_time" -ne "$initial_mod_time" ]; then
        echo "File '$file_path' has been modified."
        initial_mod_time=$current_mod_time
    fi
    sleep 1  # Check for changes every second
done
