#!/bin/bash

# Function to get the size of the file
get_file_size() {
    file_path="$1"
    if [ -e "$file_path" ]; then
        size=$(du -sh "$file_path" 2>/dev/null | cut -f1)
        echo "File size: $size"
    else
        echo "File does not exist."
    fi
}

# Prompt the user for the file path
while true; do
    read -e -p "Enter file path: " file_path
    if [ -n "$file_path" ]; then
        get_file_size "$file_path"
    else
        echo "Please enter a file path."
    fi
done
