#!/bin/bash

get_system_info() {
  echo -e "$(whoami)\n$(hostname)\n$(uname -r)"
}

while true; do 
  get_system_info 
  sleep 60
done

