#!/bin/bash

# List of IPs or domain names to ping
targets=("8.8.8.8" "8.8.4.4" "example.com" "example1.com" )

# Log file location
log_file="/var/log/network_health.log"

# Email settings
email_recipient="mohitkh172@gmail.com"
email_subject="Network Health Alert"

# Function to send email alert
send_email_alert() {
    local message=$1
    echo -e "$message" | mail -s "$email_subject" "$email_recipient"
}

# Function to check network health
check_network_health() {
    for target in "${targets[@]}"; do
        if ! ping -c 1 "$target" &> /dev/null; then
            timestamp=$(date '+%Y-%m-%d %H:%M:%S')
            echo "[$timestamp] Ping to $target failed." | tee -a "$log_file"
            send_email_alert "[$timestamp] Ping to $target failed."
        fi
    done
}

# Run the network health check periodically
while true; do
    check_network_health
    sleep 60  # Check every 60 seconds
done
