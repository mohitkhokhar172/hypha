#!/bin/bash

# Function to display free disk space
check_disk_space() {
    local partition=$1
    while true; do
        free_space=$(df -h "$partition" | awk 'NR==2 {print $4}')
        echo "Available space on $partition: $free_space"
        sleep 60  # Wait for 60 seconds before updating again
    done
}

# Prompt the user for the partition to check
read -p "Enter the partition to check (e.g., /, /home): " partition

# Check if the entered partition is valid
if ! df -h "$partition" > /dev/null 2>&1; then
    echo "Invalid partition: $partition"
    exit 1
fi

# Run the disk space check
check_disk_space "$partition"
