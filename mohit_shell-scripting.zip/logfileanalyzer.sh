#!/bin/bash

# Function to extract and analyze log file
analyze_log_file() {
    local log_file="$1"
    
    # Most frequent IP addresses
    echo "Most frequent IP addresses:"
    awk '{print $1}' "$log_file" | sort | uniq -c | sort -nr | head -n 10
    echo ""

    # Most frequent request URLs
    echo "Most frequent request URLs:"
    awk '{print $7}' "$log_file" | sort | uniq -c | sort -nr | head -n 10
    echo ""

    # Error code occurrences
    echo "Error code occurrences:"
    awk '{print $9}' "$log_file" | grep -E '4[0-9]{2}|5[0-9]{2}' | sort | uniq -c | sort -nr
    echo ""
}

# Prompt the user for the log file path
read -p "Enter the log file path: " log_file_path

# Check if the log file exists
if [ ! -f "$log_file_path" ]; then
    echo "Log file not found."
    exit 1
fi

# Run log file analysis
analyze_log_file "$log_file_path"
