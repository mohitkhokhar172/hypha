#!/bin/bash

# Function to list user accounts and last login time
list_users_last_login() {
    echo "List of user accounts and last login time:"
    lastlog -u 0-1000  # List user accounts with UID 0-1000
    echo ""
}

# Function to check file permissions in sensitive directories
check_file_permissions() {
    echo "Files with overly permissive permissions in sensitive directories:"
    find /etc /var -type f \( -perm -o+w \) -exec ls -ld {} + 2>/dev/null
    echo ""
}

# Run user account audit
list_users_last_login

# Run file permissions audit
check_file_permissions
