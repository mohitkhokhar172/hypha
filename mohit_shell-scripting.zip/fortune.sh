#!/bin/bash

# Array of predefined fortune messages
fortunes=(
    "You will have a great day!"
    "Good fortune is coming your way."
    "Be patient; everything is coming together."
    "You will achieve your goals."
    "Happiness is just around the corner."
    "Believe in yourself and all that you are."
    "Something wonderful is about to happen."
    "You are capable of amazing things."
    "Great things take time; be patient."
    "Stay positive, work hard, make it happen."
)

# Function to display a random fortune message
display_random_fortune() {
    local index=$((RANDOM % ${#fortunes[@]}))
    echo "${fortunes[$index]}"
}

# Loop to display a new fortune every 5 seconds
while true; do
    display_random_fortune
    sleep 5  # Wait for 5 seconds before displaying the next fortune
done
